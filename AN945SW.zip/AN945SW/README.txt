AN945SW: EFM8 Factory Bootloader Support Package
Copyright (c) 2018 by Silicon Laboratories Inc.

Revision 0.3   March 2018
=================================================

This software package is a companion to Silicon Labs Application Note AN495, 
"EFM8 Factory Bootloader User Guide" Rev 0.3. It provides all of the utilities,
firmware and source code referenced in the AN945 document.

All EFM8 devices are factory programmed with either a UART, USB, or 
SMBus bootloader that can be used for production programming or for field 
updates. AN945 provides a detailed description of the features,
design and operation of the EFM8 bootloader. AN945 also describes the  
utilities for working with the bootloader, and provides information 
on how to customize the bootloader if desired.

The AN945SW package is organized as follows:

 AN945SW (top level directory)
 |
 |--- ProductionDeviceHexfiles
 |       This subdirectory contains pre-built bootloader hexfiles for all 
 |       variants of production EFM8 devices.
 |
 |--- StarterKitHexfiles
 |       This subdirectory contains the bootloader hexfiles that are used with 
 |       various Starter Kit (STK) boards. With one exception, these files are 
 |       duplicates of the bootloaders for the specific devices that are used on 
 |       the various STK boards; duplicating the STK bootloaders here allows the 
 |       user to easily re-flash the STK bootloader if it is erased. The exception 
 |       is that the EFM8LB12F64E device used on the EFM8 Laser Bee Starter Kit 
 |       (SLSTK2030A) uses an SMBus bootloader with SDA/SCL pin assignments that 
 |       are different than those of production EFM8LB1x-S0 and -S1 devices.
 |
 |--- Tools
 |    |   This subdirectory contains utilities for generating and downloading 
 |    |   boot image files.
 |    |
 |    |--- 3rd_party
 |    |        This subdirectory contains the license agreements for the 
 |    |        third-party 'intelhex' and 'pyserial' packages.
 |    |
 |    |--- Source
 |    |        This subdirectory the 'efm8load.py' Python script and its 
 |    |        dependencies 'hidport.py' and 'smbport.py'.
 |    |
 |    \--- Windows
 |             This subdirectory contains the pre-built Win32 executable 
 |             files 'efm8load.exe' and 'hex2boot.exe'. These executables 
 |             have been digitally signed by Silicon Labs.
 |
 \--- README.txt (this file)


NOTES:

1. The AN945SW package does not contain bootloader source code. The bootloader 
   source code resides with the other device 'Examples' code, which is accessed 
   through Simplicity Studio.

2. The Python source code for hex2boot is not provided in the AN945SW package.
   Users must generate bootload record files using the Windows executable 
   'hex2boot.exe', or write their own software to convert hexfiles to the 
   bootload record format.

3. The 'efm8load.py' Python script can be used on Windows, Mac, and x86 Linux 
   systems. The script requires the following libraries:
   
       Windows:
           SLABHIDtoSMBus.dll
           SLABHIDDevice.dll

       Mac:
           libSLABHIDtoSMBUS.dylib
           libSLABHIDDevice.dylib

       Linux (x86):
           libslabhidtosmbus.so.1.0
           libslabhiddevice.so.1.0

   The library files listed above are included in the Windows/Mac/Linux 
   'Interface Software Development Kit Packages', which are downloadable here:
   
       www.silabs.com/products/development-tools/software/interface#software
   
   Ensure to select the 32-bit or 64-bit library files that are compatible with 
   your OS and Python installation. The library files should be copied to the 
   same directory that contains the 'efm8load.py', 'hidport.py' and 'smbport.py' 
   scripts.